<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BIGAFFI: The complete affiliate marketing solution for your ecommerce store</title>
    <link rel="shortcut icon" href="./images/bigaffilogo.jpeg" type="image/x-icon">
     <!-- ***********************************Montserrat********************************** -->
     <link rel="preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;800&family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
     <!-- *****************************OPENSANS************************ -->
     <link rel="preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- *******************Fontawesome***************************** -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="./font-awesome-4.7.0/css/font-awesome.css">
    <!-- ***********************Bootstrap******************************* -->
    <link rel="stylesheet" href="./bootstrap-5.3.0-alpha3-dist/css/bootstrap.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- ***********************Google-font*************************** -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&family=Raleway:wght@800&display=swap" rel="stylesheet">
    <!-- ******************Local Stylesheet************************* -->
    <link rel="stylesheet" href="./css/master.css">
    <link rel="stylesheet" href="./css/style.css">
    <?php echo $__env->yieldPushContent('styles'); ?>
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>

<body>
    <div id="app">
        <header>
            <nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="./index.html"><img src="./images/bigaffilogo.jpeg" alt=""></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span><i class="fa fa-bars" aria-hidden="true"></i></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link home" href="./index.html">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./pricing.html">Pricing</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="resources.html">Resources </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./contact.html">Contact</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./login-type.html">Dashboard</a>
                            </li>
                        </ul>
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link activ" href="/platforms">platforms</a>
                            </li>
                            <li class="nav-item loginBtn">
                                <a class="nav-link" href="/login">Login / Signup</a>
                            </li>

                        </ul>
                    </div>
                </div>
            </nav>
        </header>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <footer class="container-fluid">
            <div class="container">
                <div class="row row-cols-2 footer-link">
                    <div class="col-lg-3 col-sm-6 link-item">
                        <h4>For Merchant</h4>
                        <ul>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-sm-6 link-item">
                        <h4>For Affiliate</h4>
                        <ul>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-sm-6 link-item">
                        <h4>Resources</h4>
                        <ul>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-sm-6 link-item">
                        <h4>Our Policy</h4>
                        <ul>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Services</a></li>
                        </ul>
                    </div>
                </div>
                <div class="row footer-box">
                    <div class="col-lg-6 col-sm-12 footer-item">
                        <form action="#some-where" class="subscribe">
                            <p class="info">Subscribe to our monthly newsletter for the latest updates and exclusive content.</p>
                            <input type="email" placeholder="Bussiness Email...">
                            <button>Subscribe</button>
                        </form>
                    </div>
                    <div class="col-lg-4 col-sm-8 footer-item">
                        <a href=""><i class="fa fa-facebook-square" aria-hidden="true"></i></a>
                        <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                        <a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
                        <a href=""><i class="fa fa-snapchat" aria-hidden="true"></i></a>
                        <a href=""><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                        <a href=""><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                    </div>
                    <div class="col-lg-2 col-sm-4 mobile-app">
                        <a href=""><img src="./images/Google_Play_Store_badge_EN-1-01-1.svg" alt=""></a>
                        <a href="" class="d-md-none"><img src="./images/App-store-apple.svg" alt=""></a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-10 mx-auto copyright">
                        <a href=""><img src="./images/bigaffilogo.jpeg" alt=""></a>
                        <p>&copy 2023 <a href="">BigAffi LLP</a> All Right Reserved</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</body>

</html><?php /**PATH G:\wamp64\www\scoopcost\bigaffy\resources\views/layouts/web.blade.php ENDPATH**/ ?>