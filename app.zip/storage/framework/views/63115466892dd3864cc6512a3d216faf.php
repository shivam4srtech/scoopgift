<div>
    <h2 class="text-2xl font-bold mb-4">Dashboard</h2>
    <p>Welcome back, <?php echo e(auth()->user()->name); ?>!</p>
</div><?php /**PATH G:\wamp64\www\scoopcost\bigaffy\resources\views\pages/merchant/dashboard.blade.php ENDPATH**/ ?>