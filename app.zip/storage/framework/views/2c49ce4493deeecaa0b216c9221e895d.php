<?php use function Livewire\Volt\layout;
; layout('layouts.merchant'); ?>

<h2 class="text-2xl font-bold mb-4">Dashboard</h2>
<p>Welcome back, <?php echo e(auth()->user()->name); ?>!</p><?php /**PATH G:\wamp64\www\scoopcost\bigaffy\resources\views/merchant/dashboard.blade.php ENDPATH**/ ?>