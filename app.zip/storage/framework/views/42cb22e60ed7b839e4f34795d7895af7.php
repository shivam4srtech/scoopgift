

<?php $__env->startSection('content'); ?>
<section class="">
    <button class="chatbot-toggler">
        <span><i class="fa-solid fa-message"></i></span>
        <span><i class="fa fa-times" aria-hidden="true"></i></span>
    </button>
    <div class="chatbot">
        <header>
            <h2>Chatbot</h2>
            <span><i class=" close-btn fa fa-times" aria-hidden="true"></i></span>
        </header>
        <ul class="chatbox">
            <li class="chat incoming">
                <span><i class="fa-solid fa-robot"></i></span>
                <p>Hi there <br> How can I help you today?</p>
            </li>
        </ul>
        <div class="chat-input">
            <textarea placeholder="Enter a message..." required></textarea>
            <span id="send-btn"><i class="fa-solid fa-paper-plane"></i></span>
        </div>
    </div>
</section>
<!-- ***********************************BODY SECTION*************************************** -->
<section class="container description-box">
    <div class="row">
        <div class="col-lg-6 col-sm-12 site-description">
            <strong class="d-one">Welcome to <br> <span class="affiliate">gift card portal</span></strong>
            <p>Your gateway to profitable affiliate marketing.<br> Whether you're a merchant seeking to boost your sales or an affiliate looking to monetize your online presence,<br> we've got you covered.
            </p>
            <a href="" class="explore mt-3">Explore</a>
        </div>
        <div class="col-lg-6 col-sm-12 site-description">
            <img src="./images/banner.jpg" alt="">
        </div>
    </div>
</section>
<!-- ****************Where do you Fit ******************************-->
<section class="container-fluid brand">
    <div class="container">
        <h2 class="my-4">Where do you fit into the picture?</h2>
        <div class="row brand-box">
            <div class="col-md-6">
                <div class="brand-item">
                    <h3>Are You a Merchant?</h3>
                    <p>Boost your sales and compensate top-tier publishers for effectively marketing your products/services.</p>
                    <button onclick="window.location.href='./account/sign-up.html';">Register</button>
                    <button onclick="window.location.href='./account/login.html';">Login</button>
                </div>
            </div>
            <div class="col-md-6">
                <div class="brand-item">
                    <h3>Are You an Affiliate?</h3>
                    <p>Earn commissions by partnering with the world’s most widely recognized brands.</p>
                    <button onclick="window.location.href='./account/sign-up.html';">Sign-Up</button>
                    <button onclick="window.location.href='./account/login.html';">Login</button>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ************************why choose us************************************ -->
<section class="container-fluid why-bigAffi">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-10 mx-auto">
                <div class="row">
                    <h2>Why should you Choose BigAffi ?</h2>
                    <p class="join">Join the ranks of successful merchants and affiliates who have already unlocked their full earning potential.</p>
                    <div class="col-lg-3 col-md-6 col-sm-12 choose-box">
                        <div class="choose-item">
                            <img src="./images/user-friendly.jpg" alt="">
                            <span>User-Friendly Interface</span>
                            <p>
                                Seamlessly navigate our platform, whether you're a seasoned pro or new to affiliate marketing.
                            </p>
                        </div>
                    </div>
                    <!-- ************************ -->
                    <div class="col-lg-3 col-md-6 col-sm-12 choose-box">
                        <div class="choose-item">
                            <img src="./images/divercified.jpg" alt="">
                            <span>Diverse Affiliate Programs</span>
                            <p>
                                Access a wide range of industries and niches, allowing you to find the perfect match for your audience.
                            </p>
                        </div>
                    </div>
                    <!-- ************************ -->
                    <div class="col-lg-3 col-md-6 col-sm-12 choose-box">
                        <div class="choose-item">
                            <img src="./images/secure.jpg" alt="">
                            <span> Secure and Reliable</span>
                            <p>
                                Rest easy knowing that your data and earnings are protected by state-of-the-art security measures.
                            </p>
                        </div>
                    </div>
                    <!-- ************************ -->
                    <div class="col-lg-3 col-md-6 col-sm-12 choose-box">
                        <div class="choose-item">
                            <img src="./images/innovative.jpg" alt="">
                            <span>Innovative Tools</span>
                            <p>
                                Our state-of-the-art affiliate marketing tools empower you to optimize your campaigns.
                            </p>
                        </div>
                    </div>
                    <!-- ************************ -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ********************************Auto Playing carousel**************************************************** -->
<div class="logos">
    <h2 class="text-center mb-5">Trusted by over 200 companies and millions of Advertisers around the globe</h2>
    <div class="logos-slide">
        <img src="./images/cnn_scaled3.webp" />
        <img src="./images/Microsoftx200-300x79.webp" />
        <img src="./images/Bigcommerce_scaled3.png" />
        <img src="./images/shopify_scaled.webp" />
        <img src="./images/Walmart-logo-website-.webp" />
        <img src="./images/levis_200px-300x79.webp" />
        <img src="./images/Adidas_200px-300x79.webp" />
        <img src="./images/Buzzfeed_scaled.webp" />
        <img src="./images/HSBC-greyscale-logo-with-padding-light-no-bg.webp" />
        <img src="./images/ticketmaster_200px-300x79-1.webp" />
        <img src="./images/macafee_logo.webp" />
        <img src="./images/uber-logo.webp" />
    </div>
</div>

<!-- *************************************Statistics******************************************* -->
<section class="counters">
    <h2>Our Statistical Data Tells Everything</h2>
    <div>
        <div class="counter">
            <h1><span data-count="50020">0</span>+</h1>
            <h3>Stores</h3>
        </div>
        <div class="counter">
            <h1><span data-count="19870">0</span>+</h1>
            <h3>Satisfied Clients</h3>
        </div>
        <div class="counter">
            <h1><span data-count="20003">0</span>+</h1>
            <h3>Order Received</h3>
        </div>
        <div class="counter">
            <h1><span data-count="53000">0</span>+</h1>
            <h3>Clicks</h3>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\wamp64\www\scoopcost\bigaffy\resources\views/web/index.blade.php ENDPATH**/ ?>