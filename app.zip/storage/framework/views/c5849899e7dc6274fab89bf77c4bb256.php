<?php

use App\Models\GiftCard;
use Illuminate\Support\Facades\Auth;
use Livewire\Volt\Component;
use Livewire\Attributes\{Layout};

?>

<!-- Gift Card Manager UI -->
<div>
    <main>
        <div class="d-flex align-items-center">
            <div class="me-auto">
                <h1 class="title">Gift Card</h1>
            </div>
            <div class="ms-auto">
                <a href="#" wire:click='resetForm' data-bs-toggle="modal" data-bs-target="#addGiftCard" class="add-affi">Add Gift Card</a>
            </div>
        </div>

        <ul class="breadcrumbs">
            <li><a href="./merchant.html">Home</a></li>
            <li class="divider">/</li>
            <li><a href="./affiliate.html" class="active">Gift Card</a></li>
        </ul>

        <div class="card mt-4">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" data-bs-toggle="tab" href="#allAffiliate" role="tab">All Gift Card</a>
                    </li>
                </ul>
            </div>

            <div class="card-body tab-content">
                <div class="tab-pane fade show active" id="allAffiliate" role="tabpanel">
                    <div class="table-section">
                        <table>
                            <thead>
                                <tr>
                                    <th>Code</th>
                                    <th>Amount</th>
                                    <th>Balance</th>
                                    <th>Status</th>
                                    <th>Usage Limit</th>
                                    <th>Expiry Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->giftCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($gift->code); ?></td>
                                        <td><?php echo e($gift->amount); ?></td>
                                        <td><?php echo e($gift->balance); ?></td>
                                        <td><?php echo e(ucfirst($gift->status)); ?></td>
                                        <td><?php echo e($gift->usage_limit ?? '-'); ?></td>
                                        <td><?php echo e($gift->expires_at ? $gift->expires_at->format('Y-m-d') : '-'); ?></td>
                                        <td>
                                            <button wire:click='editGiftCard("<?php echo e($gift->id); ?>")' data-bs-toggle="modal" data-bs-target="#addGiftCard" class="btn btn-sm btn-primary">Edit</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-count mt-3">
            <div>
                <select name="page-count">
                    <option value="10">10 per page</option>
                    <option value="20">20 per page</option>
                    <option value="30">30 per page</option>
                    <option value="40">40 per page</option>
                </select>
            </div>
            <div>
                <p>Page <span>1</span> of <span>1</span></p>
            </div>
            <div class="next-page">
                <a href="#nextPage">Next Page</a>
            </div>
        </div>
    </main>

    <!-- Modal -->
    <div class="modal fade" id="addGiftCard" tabindex="-1" aria-labelledby="addGiftCardLabel" wire:ignore.self aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="affiliate-header">
                    <h5 class="modal-title text-center">
                        <?php echo e($this->giftCardId ? 'Edit Gift Card' : 'Add New Gift Card'); ?>

                    </h5>
                </div>

                <form wire:submit.prevent='<?php echo e($this->giftCardId ? "updateGiftCard" : "createGiftCard"); ?>'>
                    <div class="modal-body affiliate-body">
                        <div class="mb-3">
                            <label class="label col-form-label">Gift Card Code <span>*</span></label>
                            <input type="text" wire:model.defer="code" class="form-control" placeholder="Eg. GIFT500">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mb-3">
                            <label class="label col-form-label">Amount <span>*</span></label>
                            <input type="number" wire:model.defer="amount" class="form-control" step="0.01">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mb-3">
                            <label class="label col-form-label">Balance <span>*</span></label>
                            <input type="number" wire:model.defer="balance" class="form-control" step="0.01">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mb-3">
                            <label class="label col-form-label">Usage Limit</label>
                            <input type="number" wire:model.defer="usage_limit" class="form-control">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['usage_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mb-3">
                            <label class="label col-form-label">Status <span>*</span></label>
                            <select wire:model.defer="status" class="form-select">
                                <option value="active">Active</option>
                                <option value="used">Used</option>
                                <option value="expired">Expired</option>
                                <option value="disabled">Disabled</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mb-3">
                            <label class="label col-form-label">Expiry Date</label>
                            <input type="date" wire:model.defer="expires_at" class="form-control">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['expires_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>

                    <div class="affiliate-footer">
                        <a type="button" class="dismiss" data-bs-dismiss="modal">Dismiss</a>
                        <button type="submit" class="create">
                            <?php echo e($this->giftCardId ? 'Update Gift Card' : 'Create Gift Card'); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal JS Control -->
<script>
    $(document).ready(function () {
        const $modal = $('#addGiftCard');

        window.addEventListener('open-modal', function () {
            // Hide if already open (to reset state)
            const existingModal = bootstrap.Modal.getInstance($modal[0]);
            if (existingModal) {
                existingModal.hide();

                setTimeout(function () {
                    const modal = bootstrap.Modal.getOrCreateInstance($modal[0]);
                    modal.show();
                }, 200);
            } else {
                const modal = bootstrap.Modal.getOrCreateInstance($modal[0]);
                modal.show();
            }
        });

        window.addEventListener('close-modal', function () {
            const modal = bootstrap.Modal.getInstance($modal[0]);
            if (modal) {
                modal.hide();

                setTimeout(function () {
                    $('.modal-backdrop').remove();
                    $('body').removeClass('modal-open').css('padding-right', '');
                }, 500);
            }
        });
    });
</script>


</div><?php /**PATH G:\wamp64\www\scoopcost\bigaffy\resources\views\pages/merchant/gift-card.blade.php ENDPATH**/ ?>