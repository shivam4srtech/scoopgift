<?php

use function Livewire\Volt\layout;;
layout('layouts.merchant'); ?>

<div>
<main>
			<div class="d-flex align-items-center">
                <div class="me-auto">
                    <h1 class="title">Dashboard</h1>
                </div>
             
            </div>
			<ul class="breadcrumbs">
				<li><a href="./merchant.html">Home</a></li>
				<li class="divider">/</li>
				<li><a href="./affiliate.html" class="active">Dashboard</a></li>
			</ul>
            <div class="card mt-4">
                <div class="card-header">
                  <ul class="nav nav-tabs card-header-tabs id="myTab" role="tablist"">
                    <li class="nav-item" role="presentation">
                      <a class="nav-link active" aria-current="true" href="#" id="home-tab" data-bs-toggle="tab" data-bs-target="#allAffiliate" aria-controls="allAffiliate" aria-selected="true">All Gift Card</a>
                    </li>
                   
                  </ul>
                </div>
                <div class="card-body tab-content" id="nav-tabContent">
                    
         \
                  
                </div>
            </div>
           
		</main>
</div>