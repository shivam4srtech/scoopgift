<?php

use Illuminate\Support\Facades\Route;
use Livewire\Volt\Volt;
use Illuminate\Support\Facades\Auth;


Route::prefix('merchant')
    ->middleware(['auth', 'verified'])
    ->name('merchant.')
    ->group(function () {

        Volt::route('/', 'merchant.dashboard')->name('dashboard');

        Route::redirect('settings', 'merchant/settings/profile');

        Volt::route('gift-card', 'merchant.gift-card')->name('gift-card');
        Volt::route('settings/password', 'settings.password')->name('settings.password');
        Volt::route('settings/appearance', 'settings.appearance')->name('settings.appearance');

        Volt::route('coupons', 'coupons.index')->name('coupons.index');
        Volt::route('coupons/create', 'coupons.create')->name('coupons.create');
    });



Auth::routes();

Route::get('/', [App\Http\Controllers\WebController::class, 'index']);
Route::get('/platforms', [App\Http\Controllers\WebController::class, 'platforms']);

